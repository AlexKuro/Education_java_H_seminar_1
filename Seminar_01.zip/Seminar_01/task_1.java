package Seminar_01;

import java.util.Scanner;

public class task_1 {

  public static void main(String[] args) {

    // Вычислить n-ое треугольного число
    // (сумма чисел от 1 до n), n!
    // (произведение чисел от 1 до n)
    System.out.println("\nЗ А Д А Ч А  1");
    System.out.print("Вычисление n-ое треугольного число.");
    Scanner iScanner = new Scanner(System.in);
    System.out.print("\nВведите число 'n' -> ");
    int n = iScanner.nextInt();
    iScanner.close();
    int[] array = new int[n + 1];
    int temp = 0;
    for (int i = 1; i < array.length; i++) {
      array[i] = i;
      temp += array[i];
    }
    System.out.println("Число точек, которые могут быть расставлены в форме правильного треугольника: ");
    System.out.printf("1. Сумма чисел от 1 до %d\t-> %d\n", n, temp);
    System.out.printf("2. По формуле Tn = n(n+1)/2\t-> %d\n", (n * (n + 1)) / 2);
    System.out.println("\n");
  }

}
