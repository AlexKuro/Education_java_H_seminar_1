package Seminar_01;

public class task_2 {
  public static void main(String[] args) {

    // Вывести все простые числа от 1 до 1000
    System.out.println("\nЗ А Д А Ч А  2");
    System.out.println("\tВсе простые числа от 1 до 1000:");
    System.out.println("\t________Решето Сундарама_______\n");
    System.out.print("\t2 ");
    int len = 1000;
    boolean[] fl = new boolean[len + 50];
    for (int i = 1; i < len; i++) {
      fl[i] = true;
    }
    for (int i = 1; 2 * i * (i + 1) < len; i++) {
      int j_m = (len - 1) / (2 * i + 1);

      for (int j = i; j <= j_m; j++) {
        fl[2 * i * j + i + j] = false;
      }
    }
    int coun = 1;
    for (int i = 1; i <= len; i++) {
      if (fl[i]) {
        System.out.printf("\t%d", 2 * i + 1);
        coun++;
      }
      if (coun == 10) {
        System.out.println("\n");
        coun = 0;
      }
    }
    System.out.println("\n");
  }
}
